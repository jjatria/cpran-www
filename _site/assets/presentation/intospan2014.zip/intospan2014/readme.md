Readme
======

The materials in this archive were developed in October 2014, to be presented at
the 1st Symposium on Intonation and Tone in Spanish ([InToSpan][]), held in UMass,
Amherst, in the United States.

This archive contains the LaTeX source file needed for the generation of the
slides, as well as the sample sound files that accompanied the presentation.
Also included are the data files necessary for the generation of the charts and
figures, as well as a Praat script used to generate them.

Finally, the archive also includes the vectorized map of Chile used for the
slide background. This map was made and distributed by [FreeVectorMaps.com][],
and can be downloaded from the [map's website][]. No claim of ownership or similar is
made about this map, which is used with their tacit consent by following their
guidelines of non-commercial applications and proper attribution.

The recordings made available here are for sample purposes only, and remain
under the control of the researchers in charge of the projecto for which they
were collected: in this case, the [Mapa Prosódico de Chile][] project
(Fondecyt 1130720), whose principal investigator is Dr. [Domingo Román][].

If you are planning to use these materials on your own projects, we ask that you
contact the researchers to let them know, and confirm that it complies with the
applicable regulations.

If you have any other questions, please contact the author of this presentation,
[José Joaquín Atria][].

José Joaquín Atria
UCL / UMass Amherst
December, 2014

[intospan]: http://intospan2014.weebly.com
[freevectormaps.com]: http://www.freevectormaps.com/?ref=atr
[map's website]: http://www.freevectormaps.com/chile/CL-EPS-01-0001?ref=atr
[mapa prosodico de chile]: http://www7.uc.cl/letras/laboratoriodefonetica/html/investigacion/2013_Fondecyt_mpch.html
[domingo román]: mailto:dromanm@uc.cl
[josé joaquín atria]: mailto:j.atria.11@ucl.ac.uk
